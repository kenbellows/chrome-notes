/* Title:  			load_past_notes.js
 * Author: 			Ken Bellows
 * Description: 	a function load notes once the page is loaded.
 */

